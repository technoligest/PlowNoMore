export const stringResources = {
  CustomerInvoices: 'Invoices'
};
