export class Item {
  constructor(public description: string,
              public cost: number) {
  }
}
